import React, { useState } from 'react';
import { Cake, Music, Gift } from 'lucide-react';
import BirthdaySong from './components/BirthdaySong';
import WishGenerator from './components/WishGenerator';
import CakeDecoration from './components/CakeDecoration';
import MovingBalloons from './components/MovingBalloons';

function App() {
  const [showSong, setShowSong] = useState(false);
  const [showWishes, setShowWishes] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-400 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <MovingBalloons />
      <h1 className="text-4xl font-bold text-white mb-8 z-10">Happy Birthday!</h1>
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md z-10">
        <div className="flex justify-around mb-6">
          <button
            onClick={() => setShowSong(!showSong)}
            className="flex flex-col items-center text-purple-600 hover:text-purple-800 transition-colors"
          >
            <Music size={32} />
            <span>Birthday Song</span>
          </button>
          <button
            onClick={() => setShowWishes(!showWishes)}
            className="flex flex-col items-center text-pink-600 hover:text-pink-800 transition-colors"
          >
            <Gift size={32} />
            <span>Generate Wishes</span>
          </button>
        </div>
        {showSong && <BirthdaySong />}
        {showWishes && <WishGenerator />}
      </div>
      <CakeDecoration />
    </div>
  );
}

export default App;