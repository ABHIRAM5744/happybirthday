import React from 'react';
import { Cake } from 'lucide-react';

const CakeDecoration: React.FC = () => {
  return (
    <div className="mt-8 text-center">
      <Cake size={100} className="text-pink-500 mx-auto" />
      <div className="mt-4 flex justify-center">
        {[...Array(5)].map((_, index) => (
          <span key={index} className="text-2xl mx-1">🎈</span>
        ))}
      </div>
    </div>
  );
};

export default CakeDecoration;