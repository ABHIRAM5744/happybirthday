import React from 'react';

const MovingBalloons: React.FC = () => {
  const balloonColors = ['text-red-500', 'text-blue-500', 'text-green-500', 'text-yellow-500', 'text-purple-500'];

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {balloonColors.map((color, index) => (
        <div
          key={index}
          className={`absolute text-4xl ${color} animate-float`}
          style={{
            left: `${Math.random() * 100}%`,
            animationDelay: `${index * 0.5}s`,
            animationDuration: `${10 + Math.random() * 5}s`
          }}
        >
          🎈
        </div>
      ))}
    </div>
  );
};

export default MovingBalloons;