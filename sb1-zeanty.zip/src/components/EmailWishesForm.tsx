import React, { useState } from 'react';
import { Send, AlertCircle } from 'lucide-react';

const EmailWishesForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [isSent, setIsSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate sending an email
    setTimeout(() => {
      setIsSent(true);
      setIsLoading(false);
    }, 2000);
  };

  if (isSent) {
    return (
      <div className="bg-green-100 p-4 rounded-lg mb-4">
        <h2 className="text-xl font-semibold mb-4 text-green-800">Wishes Sent! (Simulation)</h2>
        <p className="text-green-700 mb-2">Your birthday wishes for {name} have been processed.</p>
        <p className="text-green-700 mb-4">
          <AlertCircle className="inline mr-2" size={20} />
          Note: This is a simulation. In a real application, an email would be sent to {email}.
        </p>
        <button
          onClick={() => {
            setIsSent(false);
            setEmail('');
            setName('');
          }}
          className="mt-2 bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-full"
        >
          Send Another
        </button>
      </div>
    );
  }

  return (
    <div className="bg-blue-100 p-4 rounded-lg mb-4">
      <h2 className="text-xl font-semibold mb-4 text-blue-800">Send Birthday Wishes (Simulation)</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-blue-700">
            Recipient's Name
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="mt-1 block w-full rounded-md border-blue-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-blue-700">
            Recipient's Email
          </label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="mt-1 block w-full rounded-md border-blue-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className={`w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-full flex items-center justify-center ${
            isLoading ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </>
          ) : (
            <>
              <Send size={20} className="mr-2" />
              Send Wishes
            </>
          )}
        </button>
      </form>
      <p className="mt-4 text-sm text-blue-600">
        <AlertCircle className="inline mr-2" size={16} />
        This is a simulation. No actual emails will be sent.
      </p>
    </div>
  );
};

export default EmailWishesForm;