import React, { useState } from 'react';
import { RefreshCw } from 'lucide-react';

const wishes = [
  "May your day be filled with laughter and love!",
  "Wishing you a year ahead full of amazing adventures!",
  "Here's to another year of creating beautiful memories!",
  "May all your dreams and wishes come true this year!",
  "Celebrating you and the wonderful person you are!"
];

const WishGenerator: React.FC = () => {
  const [currentWish, setCurrentWish] = useState('');

  const generateWish = () => {
    const randomIndex = Math.floor(Math.random() * wishes.length);
    setCurrentWish(wishes[randomIndex]);
  };

  return (
    <div className="bg-pink-100 p-4 rounded-lg mb-4">
      <button
        onClick={generateWish}
        className="bg-pink-500 hover:bg-pink-600 text-white font-bold py-2 px-4 rounded-full flex items-center mb-4"
      >
        <RefreshCw size={24} />
        <span className="ml-2">Generate Wish</span>
      </button>
      {currentWish && (
        <p className="text-center text-lg font-semibold text-pink-800">{currentWish}</p>
      )}
    </div>
  );
};

export default WishGenerator;