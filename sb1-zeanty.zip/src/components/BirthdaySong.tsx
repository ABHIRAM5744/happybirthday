import React, { useState, useRef } from 'react';
import { Play, Pause } from 'lucide-react';

const BirthdaySong: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="flex items-center justify-center bg-purple-100 p-4 rounded-lg mb-4">
      <button
        onClick={togglePlay}
        className="bg-purple-500 hover:bg-purple-600 text-white font-bold py-2 px-4 rounded-full flex items-center"
      >
        {isPlaying ? <Pause size={24} /> : <Play size={24} />}
        <span className="ml-2">{isPlaying ? 'Pause' : 'Play'} Birthday Song</span>
      </button>
      <audio ref={audioRef} loop>
        <source src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" type="audio/mpeg" />
        Your browser does not support the audio element.
      </audio>
    </div>
  );
};

export default BirthdaySong;